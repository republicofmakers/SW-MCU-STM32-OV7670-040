/*
 * lcdIli9341Config.h
 *
 *  Created on: 2017/08/25
 *      Author: take-iwiw
 */

#ifndef LCDILI9341_LCDILI9341CONFIG_H_
#define LCDILI9341_LCDILI9341CONFIG_H_

#define BIT_WIDTH_16
#define FSMC_Ax               18              // use A18 as RS
#define FSMC_NEx              1               // use subbank 1


#endif /* LCDILI9341_LCDILI9341CONFIG_H_ */
